//package org.usfirst.frc.team87.robot.interfaces;
//
//public interface PeriodicUpdates {
//	public void update();
//	public void start();
//}
