package org.usfirst.frc.team87.robot;

public class OI {

	public OI() {
		
	}

}